//# Cojocariu Sebastian <seba_sebay2008@yahoo.com>
//# Copyright 2018

#include <iostream>
// #include <stdio.h>
// #include <stdlib.h>
#include <vector>
#include <algorithm>
#include <fstream>
using namespace std;

vector<int> f(int sum, int k, int pozitie) {
	// element maxim din suma
	int n = sum-k+1;

	// dinamica
	int dp[sum+1][n+1][k+1];

	for(int i = 0; i <= n; i++)
		for(int j = 0; j <= k; j++)
			dp[0][i][j] = (j == 0)?1:0;

	for(int i = 0; i <= sum; i++)
		for(int j = 0; j <= n; j++)
			dp[i][j][0] = (i == 0)?1:0;
	for(int i = 0; i <= sum; i++)
		for(int j = 0; j <= k; j++)
			dp[i][0][j] = 0;

	for(int i = 1; i <= sum; i++) {
		for(int j = 1; j <= n; j++) {
			for(int p = 1; p <= k; p++) {
				dp[i][j][p] = 0;
				int x = dp[i][j-1][p];
				int y = (i-j >= 0)?dp[i-j][j][p-1]:0;
				dp[i][j][p] = x+y;
			}
		}
	}

	vector<int> result;
	int nr = k-1;
	// daca pozitia ceruta e >= nr de moduri de a scrie suma ceruta
	// ca suma de k termeni returnam vectorul gol
	if(pozitie >= dp[sum][n][k]) {
		return result;
	}

	int j = n;
	while(nr >= 0) {
		int s = 0;
		while(pozitie >= s) {
			if(sum-j >= 0)
				s = s + dp[sum-j][j][nr];
			j--;
		}
		j++;
		if(j != 0)
			s -= dp[sum-j][j][nr];
		pozitie -= s;
		sum = sum - j;
		result.push_back(j);
		nr--;
	}
	return result;
}

int main() {
	ifstream in("numaratoare.in");
	ofstream out("numaratoare.out");
	int sum, k, pozitie;
	in >> sum >> k >> pozitie;
	vector<int> v;
	vector<int> result;
	for(int i = 1; i <= sum-k+1; i++)
		v.push_back(i);


	result = f(sum, k, pozitie);
	if(result.size() == 0) {
		out << '-';
	} else {
		out << sum << "=";
		for(int i = 0; i < result.size(); i++) {
			out << result[i];
			if(i != result.size()-1)
				out << "+";
		}
	}
}

