//# Cojocariu Sebastian <seba_sebay2008@yahoo.com>
//# Copyright 2018

#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include <cstring>

#define MOD 1000000007
#define MAX 3000

using namespace std;

long long int ursi(char cuvant[MAX]) {
	int n = strlen(cuvant);
	int nr_ochi = 0;
	// calculam cati ochi avem in cuvant.
	for(int i = 0; i < n; i++)
		if(cuvant[i] == '^')
			nr_ochi++;
// daca avem un nr impar de ochi,inseamna ca nu putem forma niciun mesaj corect.
	if(nr_ochi%2 ==1)
		return 0;
// aloc un vector de long long int de dimensiune (nr+ochi+1).
// va fi folosit pe post de linie "anterioara" din matricea descrisa in README.
	long long int *v = (long long int *)malloc((nr_ochi+1)*sizeof(long long int));
// pentru prima pozitie din cuvant,daca incepe cu '_' nu vom putea face forma
// niciun mesaj corect,deci returnam 0.In caz contrar (avem '^'),singura
// modalitae de a crea un mesaj corect cu primul caracter este doar pt
// j=1(un mesaj corect cu fix j=1 fete neacoperite).
	for(int j = 0; j < nr_ochi+1; j++) {
		if(cuvant[0] == '^') {
			if(j == 1)
				v[j] = 1;
			else
				v[j] = 0;
		} else {
			return 0;
		}
	}

	for(int i = 1; i < n; i++) {
	// vector auxiliar in care actualizam rezultatele din linia curenta
		long long int *aux =
			(long long int *)malloc((nr_ochi+1)*sizeof(long long int));
		for(int j = 0; j < nr_ochi+1; j++) {
			aux[j] = 0;
			if(cuvant[i] == '_') {
				aux[j] = (j*v[j])%MOD;
			} else {
				long long x = (j+1 <= nr_ochi)?v[j+1]:0;
				long long y = (j-1 >= 0)?v[j-1]:0;
				aux[j] = ((j+1)*x + y)%MOD;
			}
		}
	// dezalocam v si actualizam v sa pointeze la linia curenta construita.
		free(v);
		v = aux;
	}
	return v[0];
}


int main() {
	ifstream in("ursi.in");
	ofstream out("ursi.out");
	char cuvant[MAX];
	in >> cuvant;
	out << ursi(cuvant);
}
