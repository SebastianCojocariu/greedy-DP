//# Cojocariu Sebastian <seba_sebay2008@yahoo.com>
//# Copyright 2018

#include <algorithm>
#include <iostream>
#include <vector>
#include <cmath>
#include <fstream>
using namespace std;

int minim(int a, int b) {
	return (a >= b)?b:a;
}

long long planificare(vector<int> durate, int durata_concurs,
	int pauza, int *nr_concursuri) {
	int n = durate.size();
	// a[i] = costul minim pentru elementele 0,...,i elemente din vector,
	// in care se scade si ce ramane la sfarsit
	long long *a = (long long*)malloc(n*sizeof(long long));
	// b[i] = costul minim pentru elementele 0,...,i elemente din vector,
	// in care nu se scade si ce ramane la sfarsit
	long long *b = (long long*)malloc(n*sizeof(long long));
	// nr_a[i] nr de concursuri pentru a realiza a[i]
	long long *nr_a = (long long*)malloc(n*sizeof(long long));
	// nr_b[i] = nr de concursuri pentru a realiza b[i]
	long long *nr_b = (long long*)malloc(n*sizeof(long long));
	a[0] = pow(durata_concurs-durate[0], 3);
	b[0] = 0;
	nr_a[0] = 1;
	nr_b[0] = 1;
	int i;
	for(i = 1; i < n; i++) {
		// calculam a[i];
		int j = i;
		int s = durate[i];
		a[i] = 9223372036854775807;
		b[i] = 9223372036854775807;

		nr_a[i] = nr_a[i-1];
		nr_b[i] = nr_b[i-1];

		while(j >= 0 && s <= durata_concurs) {
			if(j >= 1) {
				if(a[i] >= pow(durata_concurs - s, 3) + a[j-1]) {
					a[i] = pow(durata_concurs - s, 3) + a[j-1];
					// incrementam nr de concursuri pentru nr_a[i]
					nr_a[i] = nr_a[j-1]+1;
				}
				if(b[i] >= a[j-1]) {
					b[i] = a[j-1];
					// incrementam nr de concursuri pentru nr_a[i]
					nr_b[i] = 1 + nr_b[j-1];
				}
			// daca am ajuns cu j=0 inseamna ca toate duratele incap intr-un sg concurs
			} else {
				a[i] = pow(durata_concurs - s, 3);
				b[i] = 0;
				nr_a[i] = 1;
				nr_b[i] = 1;
			}

			j--;
			if(j >= 0)
				s += (pauza + durate[j]);
		}
	}
	*nr_concursuri = nr_b[n-1];
	return b[n-1];
}

int main() {
	ifstream in("planificare.in");
	ofstream out("planificare.out");
	int p, d, b, x;
	int nr_concursuri = -1;
	vector<int> durate;
	in >> p >> d >> b;
	for(int i = 0; i < p; i++) {
		in >> x;
		durate.push_back(x);
	}
	out << planificare(durate, d, b, &nr_concursuri);
	out << " "<< nr_concursuri;
}
