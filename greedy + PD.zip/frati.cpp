//# Cojocariu Sebastian <seba_sebay2008@yahoo.com>
//# Copyright 2018

#include <stdlib.h>
#include <stdio.h>
#include <algorithm>
#include <iostream>
#include <vector>
#include <cmath>
#include <fstream>
using namespace std;
int sam = 0;
int jon = 0;

typedef struct pereche {
	int nr_jocuri;
	int nr_benzi_desenate;
}pereche;

// functie pe care o vom folosi pentru a sorta crescator dupa suma
// dintre nr de jocuri si nr de benzi desenate al fiecarui concurs,
// iar in caz de egalitate se va alege concursul cu de nr_benzi_desenate
// mai mare
bool f(pereche x, pereche y) {
	int s = x.nr_jocuri + x.nr_benzi_desenate;
	int p = y.nr_jocuri + y.nr_benzi_desenate;
	if(p != s)
		return (p > s);
	else
		return y.nr_jocuri > x.nr_jocuri;
}

void frati(vector<pereche> perechi) {
	// sortam conform functiei f
	sort(perechi.begin(), perechi.end(), f);
	int n = perechi.size()-1;

	// cat timp nu am ajung la sfarsitul vectorului
	while(n >= 0) {
		// jon alege ultimul concurs neales inca de nimeni.
		jon += perechi[n--].nr_jocuri;
		if(n < 0)
			return;

		// gasim cea mai de "jos" pozitie pentru care suma celor 2 componente
		// este egala cu suma componentelor concursului neales inca cu suma maxima.
label:	int j = n;
		while(j >= 0 && perechi[j].nr_jocuri + perechi[j].nr_benzi_desenate ==
		 						perechi[n].nr_jocuri + perechi[n].nr_benzi_desenate)
			j--;
		j++;

		// pe pozitiile j,j+1,...,n avem sume egale.

		// daca avem un nr par de sume egale
		int nr_elem = n-j+1;
		if(nr_elem%2 == 0) {
			// va fi o succesiunea a alegerilor de forma SAM,JON,SAM,JON,...,SAM,JON
			for(int i = n; i >= j; i--)
				if((i-n)%2 == 0) {
					sam += perechi[j+(n-i)/2].nr_benzi_desenate;
				} else {
					jon += perechi[n-(n-i-1)/2].nr_jocuri;
				}
			// initializez indicele ultimului concurs cu suma maxima neales.
			n = n-(nr_elem);
			// deoarece jon a ales ultimul,sar la labelul la care sam va face alegerea.
			if(n >= 0)
				goto label;
	// altfel,daca avem un nr impar de sume egale
	// vom avea o succesiunea a alegerilor de forma SAM,JON,SAM,JON,...,SAM,JON,SAM
		} else if (nr_elem%2 == 1) {
			for(int i = n; i >= j; i--) {
				if((i-n)%2 == 0) {
					sam += perechi[j+(n-i)/2].nr_benzi_desenate;
				} else {
					jon += perechi[n-(n-i-1)/2].nr_jocuri;
				}
			}
			n = n - nr_elem;
		}
	}
}

int main() {
	ifstream in("frati.in");
	ofstream out("frati.out");
	int n;
	vector<pereche> perechi;
	in >> n;
	for(int i = 0; i < n; i++) {
		pereche p;
		in >> p.nr_jocuri >> p.nr_benzi_desenate;
		perechi.push_back(p);
	}
	frati(perechi);
	out << jon << " "<< sam;
}
